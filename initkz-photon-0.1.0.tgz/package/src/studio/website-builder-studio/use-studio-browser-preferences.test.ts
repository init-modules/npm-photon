import assert from "node:assert/strict";
import test from "node:test";
import {
	isStudioManualSaveShortcut,
	loadStudioBuilderSurfacePreference,
	loadStudioModePreference,
	persistStudioBuilderSurfacePreference,
	persistStudioModePreference,
	registerStudioManualSaveShortcut,
	resolveStudioBrowserPreferenceStorageKeys,
} from "./use-studio-browser-preferences";
import type {
	getStudioStorageItem,
	setStudioStorageItem,
} from "./studio-browser-storage";

test("mode hydration prefers URL mode over stored mode", async () => {
	const { modeStorageKey } = resolveStudioBrowserPreferenceStorageKeys("draft-key");
	const readStorage: typeof getStudioStorageItem = async <T>() =>
		"content" as T;
	const { preferredMode } = await loadStudioModePreference({
		isAdmin: true,
		hydrateModePreference: true,
		mode: "preview",
		search: "?mode=builder",
		storageKey: modeStorageKey,
		readStorage,
	});

	assert.equal(preferredMode, "builder");
});

test("mode hydration can be disabled when the host router owns mode", async () => {
	const { modeStorageKey } = resolveStudioBrowserPreferenceStorageKeys("draft-key");
	const readStorage: typeof getStudioStorageItem = async <T>() =>
		"builder" as T;
	const { preferredMode } = await loadStudioModePreference({
		isAdmin: true,
		hydrateModePreference: false,
		mode: "preview",
		search: "?mode=content",
		storageKey: modeStorageKey,
		readStorage,
	});

	assert.equal(preferredMode, null);
});

test("mode persistence stores the preference without mutating app-owned routing", async () => {
	const writes: Array<{ key: string; value: string }> = [];
	const writeStorage: typeof setStudioStorageItem = async <T>(key, value) => {
		writes.push({ key, value: value as string });
	};

	await persistStudioModePreference({
		isAdmin: true,
		hydrated: true,
		mode: "content",
		storageKey: "draft-key:mode",
		writeStorage,
	});

	assert.deepEqual(writes, [
		{
			key: "draft-key:mode",
			value: "content",
		},
	]);
});

test("builder surface hydration and persistence stay workspace-local", async () => {
	const { builderSurfaceStorageKey } =
		resolveStudioBrowserPreferenceStorageKeys("draft-key");
	const readStorage: typeof getStudioStorageItem = async <T>() =>
		"settings" as T;
	const hydrated = await loadStudioBuilderSurfacePreference({
		isAdmin: true,
		builderSurfaceMode: "canvas",
		storageKey: builderSurfaceStorageKey,
		readStorage,
	});
	const writes: Array<{ key: string; value: string }> = [];
	const writeStorage: typeof setStudioStorageItem = async <T>(key, value) => {
		writes.push({ key, value: value as string });
	};

	await persistStudioBuilderSurfacePreference({
		isAdmin: true,
		hydrated: true,
		builderSurfaceMode: hydrated.builderSurfaceMode,
		storageKey: builderSurfaceStorageKey,
		writeStorage,
	});

	assert.equal(hydrated.builderSurfaceMode, "settings");
	assert.deepEqual(writes, [
		{
			key: "draft-key:builder-surface",
			value: "settings",
		},
	]);
});

test("manual save shortcut only fires on ctrl/cmd+s without modifier conflicts", () => {
	assert.equal(
		isStudioManualSaveShortcut({
			key: "s",
			ctrlKey: true,
			metaKey: false,
			altKey: false,
			shiftKey: false,
			preventDefault: () => undefined,
		}),
		true,
	);
	assert.equal(
		isStudioManualSaveShortcut({
			key: "s",
			ctrlKey: true,
			metaKey: false,
			altKey: false,
			shiftKey: true,
			preventDefault: () => undefined,
		}),
		false,
	);

	let keydownHandler: null | ((event: Event) => void) = null;
	let saveCount = 0;
	const cleanup = registerStudioManualSaveShortcut({
		isAdmin: true,
		target: {
			addEventListener: (_eventName, handler) => {
				keydownHandler = handler as (event: Event) => void;
			},
			removeEventListener: () => {
				keydownHandler = null;
			},
		},
		onManualSave: () => {
			saveCount += 1;
		},
	});

	assert.ok(keydownHandler);

	let prevented = false;
	keydownHandler?.({
		key: "s",
		ctrlKey: true,
		metaKey: false,
		altKey: false,
		shiftKey: false,
		preventDefault: () => {
			prevented = true;
		},
	} as unknown as Event);

	assert.equal(prevented, true);
	assert.equal(saveCount, 1);

	cleanup();
	assert.equal(keydownHandler, null);
});
