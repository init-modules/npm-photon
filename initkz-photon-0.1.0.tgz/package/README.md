# @initkz/website-builder

Package-first foundation for the Website Builder runtime.

It provides:

- manifest and block definition types
- installable kit and runtime helpers
- SSR-safe builder state provider backed by a per-request Zustand store
- inline content editing primitives
- live site search primitives with stable `blockId::path` targets and exact-hit highlighting
- runtime block renderer
- reusable `WebsiteBuilderStudio` shell that apps can wrap with their own auth/backend adapters

Install from a Next.js app:

```bash
pnpm add @initkz/website-builder
```

Typical companion packages export `WebsiteBuilderModule` objects that this foundation consumes.
In the current architecture, apps usually build a runtime from installable kit objects instead of registering modules and demo documents separately.

The foundation store is initialized from server-provided document data through the package provider and then consumed in components through selector-based hooks.
That keeps SSR output stable while avoiding broad rerenders across the live canvas, palette and inspector.

When an app provides an `onSearch` handler, the default site header search can query public routes, navigate to the resolved page and highlight the exact matched occurrence on the live surface.
